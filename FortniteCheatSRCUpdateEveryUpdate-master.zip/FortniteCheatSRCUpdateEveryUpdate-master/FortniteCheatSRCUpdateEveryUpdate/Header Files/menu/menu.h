/*

Visual#9999
*/
#pragma once

namespace Render {
	bool Initialize();
}